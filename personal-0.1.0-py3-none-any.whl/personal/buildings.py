'''import pygame as pg
import itertools
import background
import text
from spritesheet import nature, building, gates
from functions import is_pressed, index_cycle

lista = []

class OutSide:
    def __init__(self, size, pos, tetto=0, muri=0, porta=0, finestre=0, name=''):
        """Per costruire l'esterno di un edificio"""
        assert tetto < 6
        assert muri < 8
        assert porta < 5
        assert finestre < 3

        self.name = name
        self.is_reading = False

        x = pos[0] - ((size[0] * 32) / 2) * (len(pos) == 3)
        y = pos[1] - ((sum(size[1:]) * 32) / 2) * (len(pos) == 3)
        pos = (x, y)
        
        s = (16, 16)

        coords = [(-1, -1), (0, -1), (1, -1),
                  (-1, 0), (0, 0), (1, 0),
                  (-1, 1), (0, 1), (1, 1)]
        
        """Il tetto può essere di cinque tipi diversi:
        -il primo tipo di tetto è fatto di tegole rosse
        -il secondo tipo di tetto è marrone chiaro
        -il terzo tipo di tetto è marrone scuro
        -il quarto tipo di tetto è grigio e ondulato
        -il quinto tipo di tetto è grigio e liscio
        """
        x, y = 80 - 64*(tetto > 2), 144 - (tetto*64*(tetto <= 2)) + ((tetto*16)*(tetto==3) - 16*(tetto==4))*(tetto>2)
    
        surf = building.images_at([(x + s[0]*a, y + s[0]*b) + s for a, b in coords])
        surf = list(map(lambda x: pg.transform.scale2x(x), surf))

        tetto = background.TileSprite(size[::2], pos, surf)

        """I muri possono essere di sette tipi diversi:
        -il primo tipo di muro è fatto di mattoni marroni;
        -il secondo tipo di muro è fatto di mattoni rosso scuro;
        -il terzo tipo di muro è fatto di mattoni rosso chiaro;
        -il quarto tipo di muro è un misto dei tre precedenti;
        -il quinto tipo di muro è fatto lunghi mattoni marroni;
        -il sesto tipo di muro è principalmente bianco con strisce grigie;
        -il settimo tipo di muro è fatto di trisce grigio chiaro e scuro.
        """

        surf = building.images_at([(s[0]*(a + 1), s[0]*(muri + b)) + s for a, b in coords[3:6]])
        surf = list(map(lambda x: pg.transform.scale2x(x), surf)) * 3

        muri = background.TileSprite(size[:2], (pos[0], tetto.rect.bottom), surf)

        """Le porte possono essere di quattro tipi diversi:
        -il primo tipo di porta è doppia e di vetro;
        -il secondo tipo di porta è singola e di vetro;
        -il terzo tipo di porta è doppia e di legno;
        -il quarto tipo di porta è singola e di legno.
        """

        surf = building.image_at((160, (16+32*porta)*(porta!=0)) + (16 + 16*(porta%2==0), 32))
        
        surf = pg.transform.scale2x(surf)
        
        self.porta = Door(surf, pos[0] + muri.rect.width/2 - surf.get_width()/2,
                                muri.rect.bottom - surf.get_height())

        """Le finestre posssono essere di due tipi diversi:
        -il primo tipo di finestra è quadrata e di vetro;
        -il secondo tipo di finestra è rettangolare e di vetro.
        """
        surf = building.image_at((128, finestre*48 + 32, finestre*16 + 16, 16))    
        surf = pg.transform.scale2x(surf)

        f1 = Door(surf, muri.rect.x + muri.rect.width/4 - surf.get_width()/2,
                        muri.rect.y + (muri.rect.height-self.porta.rect.height) / 2
                        - surf.get_height()/2)

        f2 = Door(surf, muri.rect.x + (muri.rect.width/4)*3 - surf.get_width()/2,
                        muri.rect.y + (muri.rect.height-self.porta.rect.height) / 2
                        - surf.get_height()/2)
        
        surf = nature.image_at((69, 5, 22, 21), colorkey = (0, 0, 0))
        surf = pg.transform.scale(surf, tuple(map(lambda x: int(x*1.5), surf.get_size())))
        
        self.cartello = Door(surf, muri.rect.x + 5, muri.rect.bottom + 5 - surf.get_height())

        self.sprites = [tetto, muri, self.porta, f1, f2, self.cartello]

        self.rect = pg.Rect(pos, (size[0]*32, sum(size[1:])*32))


    def read_signboard(self, person, event, color):
        """Per leggere il nome dell'edificio"""
        self.color = color
        if person.rect.colliderect(self.cartello.rect) and is_pressed('l', event):
            self.is_reading = not self.is_reading


    def render(self, screen, *args):
        """Per renderizzare tutte le parti della casa"""
        for sprite in self.sprites:
            sprite.render(screen)

        if self.is_reading:
            text.Text(self.name, size = 30).render(screen, self.color)


class Door:
    def __init__(self, surf, x, y):
        """Per creare lo sprite della porta"""
        self.surf = surf
        self.rect = surf.get_rect(x = x, y = y)

    def apri(self, person, event):
        """Per riuscire ad aprire la porta"""
        return self.rect.colliderect(person.rect) and is_pressed('e', event)

    def render(self, screen):
        """Per renderizzare l'immagine della porta"""
        screen.blit(self.surf, self.rect)



class Gate:
    def __init__(self, size, pos, type_ = (0, 0)):
        self.size = size
        
        s = (16, 16)

        x, y = type_[0] * 80 + 32, type_[1] * 80 + 32
        coords = [(-2, -2), (-1, -2), (2, -2),
                  (-2, 0), (0, 0), (2, 0),
                  (-2, 2), (-1, 2), (2, 2)]

        surf = gates.images_at([(x + s[0]*a, y + s[0]*b) + s for a, b in coords], (0, 0, 0))
        surf = list(map(lambda x: pg.transform.scale2x(x), surf))

        self.surf = background.TileSprite(size, pos, surf)
        self.rect = self.surf.rect

    def render(self, screen):
        self.surf.render(screen)


class Room:
    def __init__(self, surfs, doors, exit_=None):
        """Per creare una stanza, fatta di quatrro pareti."""
        self.surf = surfs
        assert len(surfs) == 4
        self.doors = doors
        if exit_ is not None:
            assert doors[exit_]
            self.exit = [exit_, exit_ - 4]
        self.parete = 0

    def moving(self, event):
        """Per riuscire a muoversi all'interno della stanza"""
        self.parete = index_cycle(self.surf, self.parete, -(is_pressed('left', event))
                                                          + (is_pressed('down', event) * 2)
                                                          + is_pressed('right', event))
        return is_pressed('up', event) and self.doors[self.parete]

    def render(self, screen):
        """Per renderizzare la parete cui si è di fronte"""
        screen.blit(self.surf[self.parete], (0, 0))


class Inside:
    def __init__(self, rooms):
        """Per creare l'interno di un edificio fatto di stanze"""
        self.rooms = rooms
        self.c = self.r = 0

    def update(self, event):
        """Per potersi muovere tra le stanze dell'edificio"""
        room = self.rooms[self.r][self.c]
        parete = room.parete
        if room.moving(event):
            if hasattr(room, 'exit'):
                if any([parete == n for n in room.exit]):
                    self.rooms[self.r][self.c].parete = 0
                    return True
            if 0 <= self.r < len(self.rooms) and 0 <= self.c < len(self.rooms[self.r]):
                self.r += (parete==0 or parete==-4) - (parete==2 or parete ==-2)
                self.c += (parete==1 or parete==-3) - (parete==3 or parete==-1)

            self.rooms[self.r][self.c].parete = parete

    def action(self, r, c, parete, button, event):
        if r == self.r and c == self.c:
            if any([self.rooms[r][c].parete == x for x in (parete, parete-4)]):
                return is_pressed(button, event)

    def render(self, screen):
        """Per renderizzare la stanza in cui ci si trova"""
        self.rooms[self.r][self.c].render(screen)
'''
