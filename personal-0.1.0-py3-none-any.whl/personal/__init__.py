import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = 'hide'
import pygame as pg

__version__ = '0.1.0'
__author__ = 'Samuele Amaducci'
