import pygame as pg
from functions import is_being_pressed, is_pressed
import text

class Bar:
    def __init__(self, maximum, minimum=0, height=25):
        self.progress = minimum
        self.max = maximum
        self.height = height

    def update(self):
        destra = is_being_pressed('right')
        sinistra = is_being_pressed('left')    
        self.progress += destra * (self.progress<self.max) - sinistra * (self.progress>0)
        
    def render(self, screen, color=(255,255,255), numeric_value=True, *position):
        if position:
            x_bar, y_bar = position
        else:
            x_bar = screen.get_width()/2 - self.max/2
            y_bar = screen.get_height()/2 - self.height/2
        pg.draw.rect(screen, color, (x_bar, y_bar, self.max, self.height), 1)
        pg.draw.rect(screen, color, (x_bar, y_bar, self.progress, self.height))
        if numeric_value:
            text.Text(str(self.progress), self.height, color).render(screen, None, x_bar+self.max+5, y_bar)

    def value(self):
        return self.progress


class BarGroup:
    def __init__(self, bars):
        assert all([isinstance(bar,Bar) for bar in bars])
        assert all([bar.height == bars[0].height for bar in bars])
        self.bars = bars
        self.height = bars[0].height
        self.y_choice = [self.height * 2 * bar for bar in range(len(bars))]
        self.choice = 0

    def update(self, event):
        su = is_pressed('up', event)
        giu = is_pressed('down', event)    
        self.choice += giu * (self.choice<len(self.bars)-1) - su * (self.choice!=0)

    def render(self, screen, colors, numeric_values, *position):
        if isinstance(colors, tuple):
            colors = [colors] * len(self.bars)
        if isinstance(numeric_values, bool):
            numeric_values = [numeric_values] * len(self.bars)
        if position:
            x_bars, y_bars = position
        else:
            x_bars = screen.get_width()/2 - (max([bar.max for bar in self.bars])
                                             + self.height*2)/2
            y_bars = screen.get_height()/2 - (self.height * (len(self.bars)*2 - 1))/2
        pg.draw.rect(screen, colors[self.choice], (x_bars, self.y_choice[self.choice],
                                                   self.height, self.height))
        self.y_choice = []
        for i, bar in enumerate(self.bars):
            pg.draw.rect(screen, colors[i],
                         (x_bars, y_bars, bar.height, bar.height), 1)
            bar.render(screen, colors[i], numeric_values[i],
                       x_bars+bar.height*2, y_bars)
            self.y_choice.append(y_bars)
            y_bars += self.height * 2
        self.bars[self.choice].update()

    def values(self):
        return [bar.progress for bar in self.bars]
        
