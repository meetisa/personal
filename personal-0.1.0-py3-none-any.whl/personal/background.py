import pygame as pg
from personal.functions import is_pressed, is_being_pressed
import numpy as np

class BackGround:
    def __init__(self, sections):
        """Per creare un mondo fatto di sezioni"""
        assert all([isinstance(raw,list) for raw in sections])
        self.sections = sections
        self.raws, self.columns = len(sections), len(sections[0])
        self.explored = [[False for column in range(self.columns)] for raw in range(self.raws)]
        self.raw = self.column = 0

        self.sprites = [[[] for column in range(self.columns)] for raw in range(self.raws)]
    
    def add_sprite(self, sprite, pos, *properties):
        """Per aggiungere uno sprite ad una sezione determinata da pos.
        In pos bisogna specificare la riga, la colonna e il layer in cui si è.
        Le proprietà possono essere:
        -solidità.
        """
        while 1:
            # Se il layer ancora non esiste si creano tanti layer per quanti ne mancano
            try:
                self.sprites[pos[0]][pos[1]][pos[2]].append((sprite,) + properties)
                break
            except IndexError:
                self.sprites[pos[0]][pos[1]].append([])


    def render_sprites(self, screen, *only_one):
        """Per renderizzare tutti gli sprite di una sezione"""
        for layer in self.sprites[self.raw][self.column]:
            for sprite in layer:
                sprite[0].render(screen)


    def change_section(self, nr, nc):
        """Per cambiare per sezione"""
        self.raw += nr
        self.column += nc

    def mappa(self, screen, size=50, color_back=(0,0,0),
                  color_sections=(255,255,255), color_position=(0,255,0)):
        """Per visualizzare una mappa 2d di riferimento"""
        self.X_PADDING = screen.get_width()/2 - (size*self.columns)/2
        self.Y_PADDING = screen.get_height()/2 - (size*self.raws)/2

        if color_position:        
            pg.draw.rect(screen, color_position, (self.X_PADDING + size*self.column,
                                                  self.Y_PADDING + size*self.raw,
                                                  size, size))

        for raw in range(self.raws+1):
            for column in range(self.columns+1):
                pg.draw.line(screen, color_sections,
                             (self.X_PADDING, self.Y_PADDING + size*raw),
                             (self.X_PADDING + size*self.columns, self.Y_PADDING + size*raw))
                pg.draw.line(screen, color_sections,
                             (self.X_PADDING + size*column, self.Y_PADDING),
                             (self.X_PADDING + size*column, self.Y_PADDING + size*self.raws))
                try:
                    if not self.explored[raw][column]:
                        pg.draw.rect(screen, color_sections, (self.X_PADDING + size*column,
                                                              self.Y_PADDING + size*raw,
                                                              size, size))
                except IndexError:
                    pass

    def choose_section_update(self, event):
        """Per scegliere una sezione all'interno della mappa"""
        su = is_pressed('up', event)
        destra = is_pressed('right', event)
        giu = is_pressed('down', event)
        sinistra = is_pressed('left', event)

        ec = int((self.x_rect - self.X_PADDING
                  + self.size*(- sinistra + destra)) / self.size)
        er = int((self.y_rect - self.Y_PADDING
                  + self.size*(- su + giu)) / self.size)
        w, h = self.size * (self.columns-1), self.size * (self.raws-1)
        
        try:
            self.x_rect += self.size * (- sinistra * (self.x_rect > self.X_PADDING)
                                      + destra * (self.x_rect < self.X_PADDING + w)) * self.explored[er][ec]
            self.y_rect += self.size * (- su * (self.y_rect > self.Y_PADDING)
                                      + giu * (self.y_rect < self.Y_PADDING + h)) * self.explored[er][ec]
        except IndexError:
            pass

        if is_pressed('enter', event):
            return [int((self.x_rect-self.X_PADDING) / self.size),
                    int((self.y_rect-self.Y_PADDING) / self.size)]
        
    
    def choose_section_render(self, screen, color_position=(255,0,0), size=50):
        self.X_PADDING = screen.get_width()/2 - (size*self.columns)/2
        self.Y_PADDING = screen.get_height()/2 - (size*self.raws)/2
        if not hasattr(self, 'x_rext') and not hasattr(self, 'y_rect'):
            self.x_rect = self.X_PADDING
            self.y_rect = self.Y_PADDING + size
        self.size = size
        self.mappa(screen, size, color_position = '')
        pg.draw.rect(screen, color_position, (self.x_rect,
                                              self.y_rect,
                                              size, size), 2)

    def render(self, screen):
        """Per renderizzare la sezione in cui ci si trova"""
        self.explored[self.raw][self.column] = True
        self.sections[self.raw][self.column].render(screen)

"""
class Layer:
    def __init__(self, matrix):
        \"""Per creare un layer grande quanto lo schermo\"""
        self.matrix = matrix

        coords = [(y, x) for x in range(3) for y in range(15)]
        s = (32, 32)

        # 0 - 44
        self.surf = nature.images_at([(s[0]*a, 96 + s[0]*b) + s for a, b in coords])
        
        coords2 = [(y, x) for x in range(3) for y in range(5)]

        # 45 - 59
        self.surf += nature.images_at([(s[0]*a, s[0]*b) + s for a, b in coords2], (0,0,0))
        # 60 - 74
        self.surf += nature.images_at([(480 + s[0]*a, 192 + s[0]*b) + s for a, b in coords2])

        self.surf[45] = pg.transform.scale2x(self.surf[45])
        self.surf[50] = pg.transform.scale2x(self.surf[50])

        self.surf = np.array(self.surf)
        
        self.rect = pg.Rect(0,0, self.matrix.shape[1]*self.surf[self.matrix[0][0]].get_width(),
                                 self.matrix.shape[0]*self.surf[self.matrix[0][0]].get_height())
        

    def render(self, screen):
        \"""Per renderizzare il layer\"""
        x_rect = y_rect = 0
        vehicle = 'standard'
        for ic, column in enumerate(self.matrix):
            for ir, raw in enumerate(column):
                screen.blit(self.surf[raw], (self.surf[raw].get_width()*ir,
                                             self.surf[raw].get_height()*ic))
                rect = self.surf[raw].get_rect(x = self.surf[raw].get_width()*ir,
                                               y = self.surf[raw].get_height()*ic)
                if player.io.rect.colliderect(rect):
                    if any([raw == x for x in [56, 5, 6, 7, 8, 9, 20, 22, 23, 24, 35, 36, 37]]):
                        vehicle = 'boat'
                    else:
                        vehicle = 'standard'
        player.io.which = vehicle
            

class TileSprite:
    def __init__(self, size, position, custom_surf):
        \"""Per creare uno sprite che sia fatto a sua volta di piccoli sprite\"""
        self.size = size
        self.pos = position
        self.surf = custom_surf
            
        top = [1 for _ in range(size[0] - 2)]
        top.insert(0, 0)
        top.append(2)
        bottom = [7 for _ in range(size[0] - 2)]
        bottom.insert(0, 6)
        bottom.append(8)
        self.sprite = []
        for _ in range(size[1] - 2):
            self.sprite.append([4 for _ in range(size[0] - 2)])
            self.sprite[-1].insert(0, 3)
            self.sprite[-1].append(5)
        self.sprite.insert(0, top)
        self.sprite.append(bottom)
        self.rect = pg.Rect(position,
                            tuple(l * r for l, r in zip(size, self.surf[0].get_size())))
        
    def render(self, screen):
        \"""Per renderizzare lo sprite\"""
        for ic, column in enumerate(self.sprite):
            for ir, raw in enumerate(column):
                screen.blit(self.surf[raw],
                            (self.pos[0] + self.surf[raw].get_width()*ir,
                             self.pos[1] + self.surf[raw].get_height()*ic))
"""
