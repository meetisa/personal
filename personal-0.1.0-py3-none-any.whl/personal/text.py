import pygame as pg
from personal.functions import is_pressed, playsound

pg.font.init()

def text_generator(text):
    """Per creare un generatore per comporre la stringa una per volta:
    p
    py
    pyg
    pyga
    pygam
    pygame

    (Si saltano gli spazi)
    """
    tmp = ''
    for l in text:
        tmp += l
        if l != ' ':
            yield tmp


class Text:
    """Per facilitare il renderizzamento del testo a schermo"""
    def __init__(self, text, size=20, color=(255,255,255)):
        font = pg.font.SysFont("Times new roman", size, bold = True)
        self.text = font.render(text, True, color)
        self.string = text
        self.rect = self.text.get_rect()
        self.size = font.size(text)

    def render(self, screen, color, *position):
        """Si ha la possibilità di specificare il centro del testo,
        mettendo come ultimo parametro qualsiasi cosa, tipicamente un 'center'
        """
        if position:
            if len(position) > 2:
                self.rect.center = position[:2]
            else:
                self.rect.x, self.rect.y = position
        else:
            self.rect.center = (screen.get_width()/2, screen.get_height()/2)
            
        if color:
            s = pg.Surface(screen.get_size(),pg.SRCALPHA)
            pg.draw.rect(s, color, s.get_rect())
            screen.blit(s, (0,0))

        screen.blit(self.text, self.rect)


class DynamicText:
    """Per renderizzare una frase lettera per lettera"""
    def __init__(self, text, font, color):
        self.done = False
        self.font = font
        self.text = text
        self.generated = text_generator(self.text)
        self.color = color
        self.size = font.size(text)
        self.update()

    def update(self):
        if not self.done:
            try:
                playsound('data/music/sounds/writing/-.wav')
                self.rendered = self.font.render(next(self.generated), True, self.color)
            except StopIteration:
                self.done = True
        else:
            return True

    def render(self, screen, *position):
        """Si ha la possibilità di specificare il centro del testo,
        mettendo come ultimo parametro qualsiasi cosa, tipicamente un 'center'
        """
        if position:
            if len(position) > 2:
                coordinate = (position[0] - self.size[0]/2,
                              position[1] - self.size[1]/2)
            else:
                coordinate = position
        else:
            coordinate = (screen.get_width()/2 - self.size[0]/2 ,
                          screen.get_height()/2 - self.size[1]/2)
        screen.blit(self.rendered, coordinate)


class DynamicTextGroup:
    """Per renderizzare una sequenza di frasi lettera per lettera"""
    def __init__(self, text, size = 30, color=(255,255,255)):
        font = pg.font.SysFont("Times new roman", size)
        self.text = [DynamicText(line, font, color) for line in text.split('\n')]
        self.index = 0
        self.next = False
        self.done = False
    
    def update(self, event, ms_between_letters, ms_between_lines):
        """Creo, se non esistono già, due timer: uno per il tempo di attesa
        tra le lettere, l'altro per il tempo di attesa tra le frasi
        """
        if not self.done:
            if not all([hasattr(self,attr) for attr in ['between_letters','between_lines']]):
                self.between_letters = pg.USEREVENT + 1
                pg.time.set_timer(self.between_letters, ms_between_letters)
                self.between_lines = pg.USEREVENT + 2
                pg.time.set_timer(self.between_lines, ms_between_lines)
            try:
                if event.type == self.between_letters:
                    if self.text[self.index].update():
                        self.next = True
                    else:
                        self.next = False
                if self.next and event.type == self.between_lines:
                    self.index += 1
                    self.next = False
            except IndexError:
                self.done = True
        else:
            return True

    def render(self, screen, color_back=(0,0,0), *args):
        """Si ha la possibilità di specificare il centro del testo,
        mettendo come ultimo parametro qualsiasi cosa, tipicamente un 'center'
        """
        if color_back is not None:
            screen.fill(color_back)
        try:
            if not args:
                self.text[self.index].render(screen)
            else:
                self.text[self.index].render(screen, *args)
        except (IndexError, AttributeError) as e:
            return True


class TextBox:
    """Per renderizzare una stringa multilinea, in un riquadro
    in tinta unita"""
    def __init__(self, text):
        self.lines = [Text(line) for line in text.split('\n')]

    def render(self, screen, color_box=(0,0,0)):
        pg.draw.rect(screen, color_box, (10, screen.get_height()/2,
                                          screen.get_width()-20,
                                          screen.get_height()/2 - 10))
        x_line = 15
        y_line = screen.get_height()/2 + 5
        for line in self.lines:
            line.render(screen, None, x_line, y_line)
            y_line += line.rect.height
        self.bottom = y_line + self.lines[-1].rect.height


class Question(TextBox):
    """Per renderizzare una stringa multilinea, in un riquadro
    in tinta unita, con delle opzioni da scegliere"""
    def __init__(self, text, options):
        super().__init__(text)
        self.options = [Text(line) for line in options.split('/')]
        self.index = 0

    def update(self, event):
        if is_pressed('up', event):
            if self.index > 0:
                self.index -= 1
        if is_pressed('down', event):
            if self.index < len(self.options) - 1:
                self.index += 1
        if is_pressed('enter', event):
            return self.options[self.index].string

    def render(self, screen, color_box=(0,0,0), color_mainrect=(255,255,255)):
        TextBox.render(self, screen, color_box)
        self.bottom += self.options[0].rect.height
        x_option = 15
        for option in self.options:
            option.render(screen, None, x_option, self.bottom)
            self.bottom += option.rect.height
        pg.draw.rect(screen, color_mainrect,
                     (self.options[self.index].rect[0] - 3,
                      self.options[self.index].rect[1] - 2,
                      self.options[self.index].rect[2] + 5,
                      self.options[self.index].rect[3] + 2),
                     2)
            

class QuestionGroup:
    def __init__(self, questions, options, *last_line):
        self.index = 0
        self.percorso = 0
        self.done = False
        self.questions = [[Question(questions[element][number],options[element][number])
                          for number in range(len(questions[element]))]
                          for element in range(len(options))]
        self.options = options
        if last_line:
            self.last_line = [TextBox(line) for line in last_line]

    def update(self, event):
        if not self.done:
            try:
                risposta = self.questions[self.index][self.percorso].update(event)
                if risposta:
                    self.percorso = self.options[self.index][self.percorso].split('/').index(risposta)
                    for option in self.options[self.index]:
                        if risposta in option.split('/'):
                            break
                        self.percorso += len(option.split('/'))
                    self.index += 1
                    return risposta
            except IndexError:
                self.done = True
        else:
            return True

    def render(self, screen, color_box=(0,0,0), color_mainrect=(255,255,255)):
        if not self.done:
            try:
                self.questions[self.index][self.percorso].render(screen, color_box, color_mainrect)
            except IndexError:
                pass
        elif hasattr(self,'last_line'):
            self.last_line[self.percorso].render(screen, color_box)
