import pygame as pg

def is_being_pressed(button, *args):
    """Per semplificare il rilevamento dei tasti tenuti premuti"""
    tasti = {'up': pg.K_UP, 'right': pg.K_RIGHT, 'down': pg.K_DOWN, 'left': pg.K_LEFT,
             'space': pg.K_SPACE, 'tab': pg.K_TAB, 'enter': pg.K_RETURN,
             'q': pg.K_q, 'w': pg.K_w, 'e': pg.K_e, 'r': pg.K_r, 't': pg.K_t, 'y': pg.K_y, 'u': pg.K_u, 'i': pg.K_i, 'o': pg.K_o,
             'a': pg.K_a, 's': pg.K_s, 'd': pg.K_d, 'f': pg.K_f, 'g': pg.K_g, 'h': pg.K_h, 'j': pg.K_j, 'k': pg.K_k, 'l': pg.K_l,
             'z': pg.K_z, 'x': pg.K_x, 'c': pg.K_c, 'v': pg.K_v, 'b': pg.K_b, 'n': pg.K_n, 'm': pg.K_m}

    detected = pg.key.get_pressed()

    if isinstance(button,tuple):
        if args[0] == 'uno':
            return any([detected[tasti[name]] for name in button])
        if args[0] == 'tutti':
            return all([detected[tasti[name]] for name in button])
    else:
        return detected[tasti[button]]


def is_pressed(button, event, *args):
    """Per semplificare il rilevamento dei tasti premuti per una sola volta"""
    tasti = {'up': pg.K_UP, 'right': pg.K_RIGHT, 'down': pg.K_DOWN, 'left': pg.K_LEFT,
             'space': pg.K_SPACE, 'tab': pg.K_TAB, 'enter': pg.K_RETURN,
             'q': pg.K_q, 'w': pg.K_w, 'e': pg.K_e, 'r': pg.K_r, 't': pg.K_t, 'y': pg.K_y, 'u': pg.K_u, 'i': pg.K_i, 'o': pg.K_o,
             'a': pg.K_a, 's': pg.K_s, 'd': pg.K_d, 'f': pg.K_f, 'g': pg.K_g, 'h': pg.K_h, 'j': pg.K_j, 'k': pg.K_k, 'l': pg.K_l,
             'z': pg.K_z, 'x': pg.K_x, 'c': pg.K_c, 'v': pg.K_v, 'b': pg.K_b, 'n': pg.K_n, 'm': pg.K_m}

    return event.type == pg.KEYDOWN and event.key == tasti[button]


def index_cycle(iterable, index, num):
    try:
        somma = index + num
        iterable[somma]
        return somma
    except IndexError:
        if somma < 0:
            return index_cycle(iterable, 0, somma + len(iterable))
        else:
            return index_cycle(iterable, 0, somma - len(iterable))



def swap(list_, a, b):
    list_[a], list_[b] = list_[b], list_[a]



def playsound(filename):
    pg.mixer.init()
    effect = pg.mixer.Sound(filename)
    effect.play()

    
    
    
