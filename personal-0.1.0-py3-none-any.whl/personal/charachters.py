from personal.functions import is_being_pressed
import pygame as pg
from itertools import cycle
from personal import text

class Player:
    def __init__(self, surf, screen_size, *start_position):
        """Classe per il giocatore principale."""
        self.surf = surf # Dizionario dei vari tipi di immagini
        self.which = 'standard' # Indica quale tipo di immagine si sta usando
        self.verso = 'south' # Si inizia rivolti verso l'utente
        self.indexes = cycle(range(len(self.surf[self.which][self.verso])))
        self.i = 0
        self.boat = True
        if not start_position:
            start_position = tuple(map(lambda x: int(x/2), screen_size))
        self.rect = self.surf[self.which][self.verso][self.i].get_rect(center = start_position)
        self.size = screen_size
        self.n = 0

    def set_background(self, sfondo):
        """Per impostare uno sfondo"""
        self.back = sfondo


    def north(self, v):
        """Per spostarsi a nord"""
        self.verso = 'north'
        if self.back.raw == 0:
            if self.rect.y <= 0:
                self.rect.y = 0
            else:
                self.rect.y -= v
        elif self.rect.bottom <= 0:
            self.rect.y = self.size[1]
            self.back.change_section(-1, 0)
        else:
            self.rect.y -= v
            

    def east(self, v):
        """Per spostarsi a est"""
        self.verso = 'east'
        if self.back.column == self.back.columns - 1:
            if self.rect.right >= self.size[0]:
                self.rect.right = self.size[0]
            else:
                self.rect.x += v
        elif self.rect.left >= self.size[0]:
            self.rect.right = 0
            self.back.change_section(0, 1)
        else:
            self.rect.x += v

    def south(self, v):
        """Per spostarsi a sud"""
        self.verso = 'south'
        if self.back.raw == self.back.raws - 1:
            if self.rect.bottom >= self.size[1]:
                self.rect.bottom = self.size[1]
            else:
                self.rect.y += v
        elif self.rect.top >= self.size[1]:
            self.rect.bottom = 0
            self.back.change_section(1, 0)
        else:
            self.rect.y += v

    def west(self, v):
        """Per spostarsi verso ovest"""
        self.verso = 'west'
        if self.back.column == 0:
            if self.rect.x <= 0:
                self.rect.x = 0
            else:
                self.rect.x -= v
        elif self.rect.right <= 0:
            self.rect.left = self.size[0]
            self.back.change_section(0, -1)
        else:
            self.rect.x -= v


    def moving(self, v):
        """Per muoversi in ogni direzione"""
        if is_being_pressed(('up', 'right', 'down', 'left'), 'uno'):
            if self.n % 5 == 0:
                self.i = next(self.indexes)

            self.n += 1

            if is_being_pressed('up'):
                self.north(v)
            if is_being_pressed('right'):
                self.east(v)
            if is_being_pressed('down'):
                self.south(v)
            if is_being_pressed('left'):
                self.west(v)

            self.physics()


    def render(self, screen):
        """Per renderizzare i frame del giocatore"""
        screen.blit(self.surf[self.which][self.verso][self.i], self.rect)


    def physics(self):
        """Per simulare la fisica basilare,
        per non far attraversare gli oggetti solidi tra di loro.
        """
            
        for layer in self.back.sprites[self.back.raw][self.back.column]:
            
            for sprite in layer:

                if not sprite[1]:
                    continue
            
                rect = sprite[0].rect

                if rect.collidepoint(self.rect.midbottom):
                    if self.rect.centery > rect.centery:
                        self.rect.bottom = rect.bottom
                    else:
                        self.rect.bottom = rect.top
                        
                elif rect.collidepoint(self.rect.midleft) and self.rect.bottom < rect.bottom:
                    self.rect.left = rect.right
                    
                elif rect.collidepoint(self.rect.midright) and self.rect.bottom < rect.bottom:
                    self.rect.right = rect.left
        


    def set_inventory(self, dict_):
        """Per impostare l'inventario iniziale del giocatore"""
        self.inv = dict_

    def show_inventory(self, screen):
        y = 300 - (len(self.inv)*20) / 2
        for obj in self.inv:
            text.Text(': '.join([obj, str(self.inv[obj])])).render(screen, None, 400, y, 'center')
            y += 20

    def leaves(self, obj):
        """Per fare lasciare un oggetto al giocatore"""
        if self.inv[obj] > 0:
            self.inv[obj] -= 1
        return not self.inv[obj] > 0

    def takes(self, obj):
        """Per fare prendere un oggetto al giocatore"""
        try:
            self.inv[obj] += 1
        except KeyError:
            self.inv[obj] = 1
        



class Npc(Player):
    def __init__(self, surf, start_position):

        super().__init__(self,surf)
